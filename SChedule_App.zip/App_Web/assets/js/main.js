$(document).ready(function () {
    $('#tabla1').DataTable();
});