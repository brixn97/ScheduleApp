<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Workers extends CI_Model
{
	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function getEmployees()
	{
		return $this->db->query("SELECT dni, nom, cognoms, passwd, birth, email, idA, idH FROM Treballador")->result_array();
	}
	
	public function getNewsById($dni) {
			$query = $this->db->get_where('workers', array("dni" => $dni));
			//$query = $this->db->query('SELECT * from News WHERE id = ' . $id);
			return $query->row();
		}

	public function setEmployee(string $dni, string $nom, string $cognoms, string $passwd, string $birth, string $email, string $idA, string $idH)
	{
		$dni = $this->db->escape($dni);
		$nom = $this->db->escape($nom);
		$cognoms = $this->db->escape($cognoms);
		$passwd = $this->db->escape($passwd);
		$birth = $this->db->escape($birth);
		$email = $this->db->escape($email);
		return $this->db->query("INSERT INTO Treballador (dni, nom, cognoms, passwd, birth, email, idA, idH) 
									values ({$dni}, {$nom}, {$cognoms}, {$passwd}, {$birth}, {$email}, {$idA}, {$idH})");
	}

	public function getEmployee(int $id)
	{
		return $this->db->query("SELECT dni, nom, cognoms, passwd, birth, email, idA, idH FROM Treballador WHERE dni = {$dni}")->row();
	}

	public function updateEmployee(int $dni, string $nom, string $cognoms, string $email)
	{
		return $this->db->query("UPDATE Treballador SET nom = {$nom}, cognoms = {$cognoms}, email = {$email} WHERE dni = {$dni}");
	}

	public function deleteEmployee(int $id)
	{
		return $this->db->query("DELETE FROM Treballador WHERE dni = {$dni}");
	}


	// CHECK WORKER USER / PASS
	public function userExists($uname) {
		$data = array('dni' => $uname);
		$result = $this->db->get_where('treballador', $data);
		return $result->num_rows() == 1;
	}

	public function checkUserPasswd($uname, $passwd) {
		$data = array('dni' => $uname);
		$result = $this->db->get_where('treballador', $data);
		if($result->num_rows() == 1) {
			$row = $result->row();
			return $row->passwd == $passwd;
		}
		return false;
	}

	/*public function getEmployeeID($dni)
	{
		return $this->db->query("SELECT dni FROM Treballador WHERE dni = '{$dni}'")->row();
	}*/
}