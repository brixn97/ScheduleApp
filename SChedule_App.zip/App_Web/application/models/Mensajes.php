<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Mensajes extends CI_Model
{
	function __construct()
	{
		parent::__construct();
		$this->load->database();
    }
    
    function setMessage($motiu, $descripcio, $idA, $idT){
        $motiu = $this->db->escape($motiu);
        $descripcio = $this->db->escape($descripcio);
        $idA = $this->db->escape($idA);
        $idT = $this->db->escape($idT);
		
		return $this->db->query("INSERT INTO messages (titol, motiu, ida, idt) 
									values ({$motiu}, {$descripcio}, {$idA}, {$idT})");
    }
}