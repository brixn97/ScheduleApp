<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Faults extends CI_Model
{
	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function getFaults()
	{
		return $this->db->query("SELECT dniT, nomT, cognomsT, idA, motiu FROM Falta")->result_array();
	}

	public function setFault(string $dniT, string $nomT, string $cognomsT, string $idA, string $motiu)
	{
		$dniT = $this->db->escape($dniT);
		$nomT = $this->db->escape($nomT);
		$cognomsT = $this->db->escape($cognomsT);
		$idA = $this->db->escape($idA);
		$motiu = $this->db->escape($motiu);
		return $this->db->query("INSERT INTO Falta (dniT, nomT, cognomsT, idA, motiu) 
									values ({$dniT}, {$nomT}, {$cognomsT}, {$idA}, {$motiu})");
	}

	public function getFault(int $id)
	{
		return $this->db->query("SELECT dniT, nomT, cognomsT, idA, motiu FROM Falta WHERE dniT = {$dniT}")->row();
	}

	public function updateEmployee(int $dni, string $nom, string $cognoms, string $email)
	{
		return $this->db->query("UPDATE Treballador SET nom = {$nom}, cognoms = {$cognoms}, email = {$email} WHERE dni = {$dni}");
	}

	public function deleteEmployee(int $id)
	{
		return $this->db->query("DELETE FROM Treballador WHERE dni = {$dni}");
	}


}