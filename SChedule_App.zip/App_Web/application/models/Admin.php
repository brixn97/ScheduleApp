<?php
    class Admin extends CI_Model {

        public function __construct() {
            $this->load->database();
        }

        public function getPublicUserData($uname) {
            $result = $this->db->query("SELECT uname, rname, email, passwd FROM administrador WHERE uname = '" . $uname . "';");
            return $result->row();
        }
		
		public function getAdmins() {
            $result = $this->db->query("SELECT rname, uname FROM Administrador;");
            return $result->result_array();
        }

        public function addUser($rname, $uname, $email, $passwd) {
            $data = array(
                'rname' => $rname,
                'uname' => $uname,
                'email' => $email,
                'passwd' => $passwd
            );

            $this->db->insert('administrador', $data);
        }

        public function userExists($uname) {
            $data = array('uname' => $uname);
            $result = $this->db->get_where('administrador', $data);
            return $result->num_rows() == 1;
        }

        public function checkUserPasswd($uname, $passwd) {
            $data = array('uname' => $uname);
            $result = $this->db->get_where('administrador', $data);
            if($result->num_rows() == 1) {
                $row = $result->row();
                return $row->passwd == $passwd;
            }
            return false;
        }

     
        

    }
?>