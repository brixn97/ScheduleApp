<?php
	class Schedule extends CI_Model {

		public function __construct() {
			$this->load->database();
		}

		public function getNews($ini=NULL, $limit=NULL) {
			if($ini === NULL || $limit === NULL) {
				$this->db->order_by('creation_date', 'DESC');
				$query = $this->db->get('news');
			} else {
				$query = $this->db->query("SELECT * FROM news ORDER BY creation_date DESC LIMIT " . $limit . " OFFSET " . $ini . ";");
			}
				
			return $query->result_array();
		}

		public function getNewsById($id) {
			$query = $this->db->get_where('news', array("id" => $id));
			//$query = $this->db->query('SELECT * from News WHERE id = ' . $id);
			return $query->row();
		}

		public function getNewsByDay($day, $month, $year, $ini=NULL, $limit=NULL) {
			$iniday = $year . "-" . $month . "-" . $day . " 00:00:00";
			$endday = $year . "-" . $month . "-" . $day . " 23:59:59";
			if($ini === NULL || $limit === NULL) {
				$query = $this->db->query("SELECT * FROM news WHERE creation_date >= '" . $iniday . "' AND creation_date <= '" . $endday . "' ORDER BY creation_date DESC;");
			} else {
				$query = $this->db->query("SELECT * FROM news WHERE creation_date >= '" . $iniday . "' AND creation_date <= '" . $endday . "' ORDER BY creation_date DESC LIMIT " . $limit . " OFFSET " . $ini . ";");
		    }
			return $query->result_array();
		}

		public function setUser($dni, $nom, $cognoms, $passwd) {
			$data = array(
				'dni' => $dni,
				'nom' => $nom,
				'cognoms' => $cognoms,
				'passwd' => $passwd
			);
			$this->db->insert('Treballador', $data);
			//$this->db->query($this->db->insert_string('news', $data));
			//$this->db->query("INSERT INTO news (title, content, uname, creation_date) VALUES ('" . $title . "', '" . $content . "', '" . $uname . "', CURRENT_TIMESTAMP);");            
		}

		public function getTotalNumOfNews() {
			$query = $this->db->query("SELECT COUNT(id) AS num FROM News;");
			return $query->row()->num;
		}

		public function getTotalNumOfNewsInDay($day, $month, $year) {
			$iniday = $year . "-" . $month . "-" . $day . " 00:00:00";
			$endday = $year . "-" . $month . "-" . $day . " 23:59:59";
			$query = $this->db->query("SELECT COUNT(id) AS num FROM news WHERE creation_date >= '" . $iniday . "' AND creation_date <= '" . $endday . "';");
			return $query->row()->num;
		}

	}
?>