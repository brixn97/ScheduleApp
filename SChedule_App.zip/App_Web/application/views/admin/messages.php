<div class="container">
    <div class="col-lg-12 text-center">
        <h2 class="mt-5">MENSAJES RECIBIDOS</h2>
    </div>
</div>
