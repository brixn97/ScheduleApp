<style>
  .container{
    padding:5%;
}
.container .img{
    text-align:center;
}
.container .details{
    border-left:3px solid #ded4da;
}
.container .details p{
    font-size:15px;
    font-weight:bold;
}

</style>

<div class="container">
  <div class="row">
    <div class="col-md-6 img">
      <img src="<?php echo base_url('assets/img/profile-photo.png'); ?>" class="profile-photo">
    </div>
    <div class="col-md-6 details">
      <blockquote>
        <h5><?php echo $rname ?></h5>
        <small><cite title="Source Title">Administrador<i class="icon-map-marker"></i></cite></small>
      </blockquote>
      <p>
        Usuario: <?php echo $uname ?> <br>
        Contraseña: <?php echo $passwd; ?> <br>
      </p>
    </div>
  </div>
</div>