<?php echo validation_errors();?>

<title>Bootstrap Table with Add and Delete Row Feature</title>
<br>
<div class="card card-outline-secondary">
    <div class="card-header">
        <center><h3 class="mb-0">AÑADE, EDITA Y MODIFICA TRABAJADORES</h3></center>
    </div>
            
	<div class="card-body">
		<?php echo form_open('user/create', "class='form' role='form' autocomplete='off'"); ?>
            <div class="form-group row">
                <label class="col-lg-3 col-form-label form-control-label">DNI</label>
            	<div class="col-lg-9">
            		<input type="text" name="dni" class="form-control" required="true">
            	</div>
    		</div>
                    
			<div class="form-group row">
                <label class="col-lg-3 col-form-label form-control-label">Nombre</label>
                <div class="col-lg-9">
					<input type="text" name="nom" class="form-control" required="true">
                </div>
            </div>
                    
			<div class="form-group row">
                <label class="col-lg-3 col-form-label form-control-label">Apellidos</label>
                <div class="col-lg-9">
					<input type="text" name="cognoms" class="form-control" required="true">
                </div>
            </div>
                                
			<div class="form-group row">
                <label class="col-lg-3 col-form-label form-control-label">Contraseña</label>
                <div class="col-lg-9">
					<input type="password" name="passwd" class="form-control" required="true">
                </div>
            </div>

			<div class="form-group row">
                <label class="col-lg-3 col-form-label form-control-label">Fecha Nacimiento</label>
                <div class="col-lg-9">
                    <input type="date" name="birth" class="form-control" required="true">
                </div>
            </div>
                                
			<div class="form-group row">
                <label class="col-lg-3 col-form-label form-control-label">Email</label>
                <div class="col-lg-9">
					<input type="text" name="email" class="form-control" required="true">
                </div>
            </div>

			<div class="form-group row">
                <label class="col-lg-3 col-form-label form-control-label">id Administrador</label>
                <div class="col-lg-9">
					<input type="text" name="idA" class="form-control" required="true">
                </div>
            </div>
                                
			<div class="form-group row">
                <label class="col-lg-3 col-form-label form-control-label">Horario</label>
                <div class="col-lg-9">
					<input type="text" name="idH" class="form-control" required="true">
                </div>
            </div>
			
			<div class="clearfix"></div>

			<center>
				<input type="submit" class="btn btn-primary" name="" value="Guardar">
				<input type="reset" class="btn btn-danger" value="Limpiar">
			</center>
		</form>
	</div>
</div>
<br>

<center>
	<div class="row-workers">
		<div class="col-lg-7">
			<table border="1" class="table table-striped table-bordered table-hover table-condensed">
						<tr>
						<th>DNI</th>
						<th>Nombre</th>
						<th>Apellidos</th>
						<th>Contraseña</th>
						<th>Fecha Nacimiento</th>
						<th>Correo</th>
						<th>idA</th>
						<th>idH</th>
						<th colspan="2">Opciones</th>
						</tr>

					<?php
						foreach($Workers as $worker)
						{
							echo "<tr>"."<td>".$worker['dni']."</td>".
							"<td>".$worker['nom']."</td>".
							"<td>".$worker['cognoms']."</td>".
							"<td>".$worker['passwd']."</td>".
							"<td>".$worker['birth']."</td>".
							"<td>".$worker['email']."</td>".
							"<td>".$worker['ida']."</td>".
							"<td>".$worker['idh']."</td>".
							"<td><a href='WorkersController/modifyEmployee/".$worker['dni']."'><span class='glyphicon glyphicon-user'></span>Modificar</a></td>".
							"<td><a href='WorkersController/deleteEmployee/".$worker['dni']."'><span class='glyphicon glyphicon-user'></span>Eliminar</a></td>".
							"</tr>";
						}
					?>	
			</table>
		</div>
	</div>
</center>