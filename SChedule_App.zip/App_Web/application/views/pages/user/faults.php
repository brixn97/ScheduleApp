<?php echo validation_errors();?>

<div class="container contact-form">    
    <?php echo form_open('user/faults', "role='form' autocomplete='off'"); ?>
        <h3>Añade faltas a tus trabajadores</h3>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <input type="text" name="dniT" class="form-control" placeholder="DNI Trabajador" value="" required/>
                </div>

                <div class="form-group">
                    <input type="text" name="nomT" class="form-control" placeholder="Nombre" value="" required/>
                </div>

                <div class="form-group">
                    <input type="text" name="cognomsT" class="form-control" placeholder="Apellidos" value="" required/>
                </div>

                <div class="form-group">
                    <input type="text" name="idA" class="form-control" placeholder="id Administrador" value="" required/>
                </div>

                <div class="form-group">
                    <input type="submit" name="btnSubmit" class="btnContact" value="Enviar" required/>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <textarea name="motiu" class="form-control" placeholder="Motivo de la falta" style="width: 100%; height: 150px;"></textarea>
                </div>
            </div>
        </div>
    </form>
</div>

<center>
	<div class="row-workers">
		<div class="col-lg-7">
         <form action="" method="post" class="form"></form>
            <input type="text" name="busqueda">
            <input type="submit" value="Buscar">
        </form>
         <br>
			<table id="tabla1" border="1" class="table table-striped table-bordered table-hover table-condensed">
						<tr>
						<th>DNI</th>
						<th>Nombre</th>
						<th>Apellidos</th>
						<th>idA</th>
						<th>Motivo</th>
						<th colspan="2">Opciones</th>
						</tr>

					<?php
						foreach($Faults as $fault)
						{
							echo "<tr>"."<td>".$fault['dnit']."</td>".
							"<td>".$fault['nomt']."</td>".
							"<td>".$fault['cognomst']."</td>".
							"<td>".$fault['ida']."</td>".
							"<td>".$fault['motiu']."</td>".
							"<td><a href='FaultsController/deleteFault/".$fault['dnit']."'><span class='glyphicon glyphicon-user'></span>Eliminar</a></td>".
							"</tr>";
						}
					?>	
			</table>
		</div>
	</div>
</center>