<?php echo validation_errors();?>

<center><h3>INCIDENCIAS RECIBIDAS</h3></center>