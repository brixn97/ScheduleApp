<br>
<br>
<center>
<div class="container">
	<table class="table-schedule">
		<thead class="cabecera-horario">
			<tr>
				<th></th>
				<th>Lunes</th>
				<th>Martes</th>
				<th>Miercoles</th>
				<th>Jueves</th>
				<th>Viernes</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="hora-horario">09:00 - 10:00</td>
				<td>Inventario</td>
				<td>Atencion al cliente</td>
				<td>Inventario</td>
				<td>Inventario</td>
				<td>Soporte</td>
			</tr>
			<tr>
				<td class="hora-horario">10:00 - 11:00</td>
				<td>Soporte</td>
				<td>Inventario</td>
				<td>Inventario</td>
				<td>Soporte</td>
				<td>Atencion al cliente</td>
			</tr>
			<tr>
				<td class="hora-horario">11:00 - 12:00</td>
				<td>Soporte</td>
				<td>Atencion al cliente</td>
				<td>Inventario</td>
				<td>Inventario</td>
				<td>Atenion al cliente</td>
			</tr>
			<tr>
				<td class="hora-horario">12:00 - 13:00</td>
				<td>Inventario</td>
				<td>Atencion al cliente</td>
				<td>Inventario</td>
				<td>Inventario</td>
				<td>Soporte</td>
			</tr>
			<tr>
				<td class="hora-horario">14:00 - 15:00</td>
				<td>Inventario</td>
				<td>Atencion al cliente</td>
				<td>Inventario</td>
				<td>Inventario</td>
				<td>Soporte</td>
			</tr>
		</tbody>
	</table>
</div>
</center>