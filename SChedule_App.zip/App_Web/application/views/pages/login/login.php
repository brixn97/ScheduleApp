<?php echo validation_errors(); ?>

<body background="<?php echo base_url('assets/img/login-background.jpg'); ?>" class="body">
    <img class="logo-login" src="<?php echo base_url('assets/img/logo-fijo.png'); ?>" />
    <br>
    <div class="slogan">
        <h1>· TU HORARIO AL ALCANCE ·</h1>
    </div>
    <br>
    <!-- REGISTRE -->
    <div class="row" style= "border: 1px;">
        <div class="col simple-reg-container">
            <h2>REGÍSTRATE</h2>
            <?php echo form_open('login/reg'); ?>
            <br>
            <div class="row">
                <div class="col-md-12 form-group">
                    <input id="rname" name="rname"type="text" class="form-control" placeholder="nombre y apellidos">
                </div>
            </div>

            <div class="row">
                <div class="col-md-12 form-group">
                    <input id="eaddr" name="eaddr" type="email" class="form-control" placeholder="correo electronico">
                </div>
            </div>

            <div class="row">
                <div class="col-md-12 form-group">
                    <input id="uname" name="uname"type="text" class="form-control" placeholder="nombre de usuario">
                </div>
            </div>

            <div class="row">
                <div class="col-md-12 form-group">
                    <input id="passwd" name="passwd" type="password" class="form-control" placeholder="contraseña">
                </div>
            </div>

            <div class="row">
                <div class="col-md-12 form-group">
                    <input type="submit" class="btn btn-block btn-reg" name="register" value="Registrarme">
                </div>
            </div>
            </form>
        </div>

        <!-- LINEA VERTICAL -->
        <hr class="v" />


    <!-- LOGIN -->
        <div class="col simple-login-container">
            <h2>ACCEDE A TU PORTAL!</h2>
            <?php echo form_open('login/log'); ?>
            <br>
            <div class="row">
                <div class="col-md-12 form-group">
                    <input id="rname" name="uname" type="text" class="form-control" placeholder="nombre de usuario">
                </div>
            </div>

            <div class="row">
                <div class="col-md-12 form-group">
                    <input type="password" name="passwd" placeholder="contraseña" class="form-control">
                </div>
            </div>

            <div class="row">
                <div class="col-md-12 form-group">
                    <input type="submit" name="log" class="btn btn-block btn-login">
                </div>
            </div>
            </form>
        </div>
    </div>
</body>