<br>
<center>
  <h3>Quieres salir?</h3>
</center>
  <?php echo form_open('logout'); ?>
  <center>
    <button type="submit" name="logout" value="yes">SI</button>
    <button type="submit" name="continue" value="no">NO</button>
  </center>
  </form>
