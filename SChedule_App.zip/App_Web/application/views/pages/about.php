        <h2>Pàgina d'informació</h2>
        <p>Primera aplicació CI creada pels alumnes de 2n de DAW.</p>