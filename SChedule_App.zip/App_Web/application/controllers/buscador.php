<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class buscador extends CI_Controller {







    public function index()
        if($_POST){

        }else{

        }

        $this->load->model('buscar_mod');
        $data['faults'] = $this->buscar_mod->buscar($buscar);