<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class WorkersController extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model("Workers");
		$this->load->helper("url_helper");
		$this->load->helper("cookie");
		$this->load->helper("form");

		//Check session
            $this->load->helper('cookie');
            if(get_cookie('ci_session') != NULL) {
                $this->load->library('session');
            }
	}

	public function index()
	{
		$Workers = $this->Workers->getEmployees();
		$this->layout->view("Employees", compact("Employees"));
	}

	public function create() {
            if(!isset($this->session)) {
                redirect('schedule');
            }
            if(isset($this->session)) {
                $data['rname'] = $this->session->rname;
                $data['uname'] = $this->session->uname;
            }


            $this->load->helper('form');
            $this->load->library('form_validation');

            $this->form_validation->set_rules('dni', 'DNI', 'required');
            $this->form_validation->set_rules('nom', 'NOM', 'required');
            $this->form_validation->set_rules('cognoms', 'COGNOMS', 'required');
            $this->form_validation->set_rules('passwd', 'PASSWORD', 'required');
            $this->form_validation->set_rules('birth', 'BIRTH', 'required');
            $this->form_validation->set_rules('email', 'EMAIL', 'required');
            $this->form_validation->set_rules('idA', 'IDA', 'required');
            $this->form_validation->set_rules('idH', 'IDH', 'required');

            $data['title'] = "Nuevo Trabajador";
            $data['Workers'] = $this->Workers->getEmployees();

            if($this->form_validation->run() == FALSE) {
                $this->load->view('templates/header', $data);
                $this->load->view('pages/user/create');
                $this->load->view('templates/footer');
            } else {
				$dni = $_POST["dni"];
			$nom = $_POST["nom"];
			$cognoms = $_POST["cognoms"];
			$passwd = $_POST["passwd"];
			$birth = $_POST["birth"];
			$email = $_POST["email"];
			$idA = $_POST["idA"];
			$idH = $_POST["idH"];
			if ($this->Workers->setEmployee($dni, 
											$nom, 
											$cognoms,
											$passwd,
											$birth,
											$email,
											$idA,
											$idH))
			{
				/*var_dump($data['Workers']);*/
				$data["correct"] = TRUE;
				$data['Workers'] = $this->Workers->getEmployees();
				
				$this->load->view('templates/header');
                $this->load->view('pages/user/create', $data);
                $this->load->view('templates/footer');
			}
		}
	}

	public function saveEmployee()
	{
		if($this->input->post())
		{
			$dni = $_POST["dni"];
			$nom = $_POST["nom"];
			$cognoms = $_POST["cognoms"];
			$passwd = $_POST["passwd"];
			$birth = $_POST["birth"];
			$email = $_POST["email"];
			$idA = $_POST["idA"];
			$idH = $_POST["idH"];
			if ($this->Workers->setEmployee($dni, 
											$nom, 
											$cognoms,
											$passwd,
											$birth,
											$email,
											$idA,
											$idH))
			{
				$data["correct"] = TRUE;
				$this->load->view('templates/header');
                $this->load->view('pages/user/create', $data);
                $this->load->view('templates/footer');
			}

		}
	}

	public function modifyEmployee($dni = null)
	{
		if (!$dni == null)
		{
			$id = $this->db->escape((int)$dni);
			$Employee = $this->Workers->getEmployee($dni);
			$this->layout->view("modifyEmployee", compact("Employee"));
		}
		else
		{
			header("Location:".base_url()."employees");
		}
	}

	public function updateEmployee()
	{
		if($this->input->post())
		{
			$id = $this->db->escape((int)$_POST["id"]);
			$first_name = $this->db->escape($_POST["first_name"]);
			$last_name = $this->db->escape($_POST["last_name"]);
			$email_address = $this->db->escape($_POST["email_address"]);
			if ($this->EmployeesModel->updateEmployee($id, $first_name, $last_name, $email_address))
			{
				header("Location:".base_url()."Trabajadores");
			}
		}
	}

	public function deleteEmployee(int $id)
	{
			if ($this->Workers->deleteEmployee($id))
			{
				header("Location:".base_url()."Trabajadores");
			}
	}

	public function incidencias(){
		$this->load->view('templates/header');
        $this->load->view('pages/user/incidencias');
        $this->load->view('templates/footer');
	}
}