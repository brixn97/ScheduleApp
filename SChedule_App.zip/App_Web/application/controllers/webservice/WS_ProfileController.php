<?php
    use Restserver\Libraries\REST_Controller;
    require_once(APPPATH . 'controllers/webservice/WS_Controller.php');

    class WS_ProfileController extends WS_Controller {

        public function __construct() {
            parent::__construct();

            $this->load->model('admin');

            $this->load->helper('form');
            $this->load->helper('url_helper');

            $this->load->library('form_validation');
        }

        public function getUsersList_get() {
            $this->setHeaders();
            $this->response($this->admin->getAdmins(), REST_Controller::HTTP_OK);
        }

        public function getUserProfile_post() {
            //Ens hem d'imaginar que, sigui mòbil o sigui web, hi ha un formular post al darrera
            $this->setHeaders();

            $this->form_validation->set_rules('uname', 'User uname', 'required');
            if($this->form_validation->run() == FALSE) {
                $rdata = array(
                    'message' => validation_errors()
                );
                $this->reponse($rdata, REST_Controller::HTTP_BAD_REQUEST);
            } else {
                $detail = $this->admin->getPublicUserData($this->input->post('uname'), TRUE);
                $this->response($detail, REST_Controller::HTTP_OK);
            }
        }

        public function getUserProfile_options() {
            $this->setOptions();
        }

    }
?>