<?php
    use Restserver\Libraries\REST_Controller;   //REST_Controller pertany a un namespace
    use Firebase\JWT\JWT;
    require_once(APPPATH . 'vendor/chriskacerguis/codeigniter-restserver/libraries/REST_Controller.php');
    require_once(APPPATH . 'vendor/chriskacerguis/codeigniter-restserver/libraries/Format.php');
    require_once(APPPATH . 'vendor/firebase/php-jwt/JWT.php');
    require_once(APPPATH . 'vendor/firebase/php-jwt/SignatureInvalidException.php');

    class WS_Controller extends REST_Controller {

        public function __construct() {
            parent::__construct();

            $this->load->model('token');
        }

        protected function setHeaders($token = NULL) {
            $this->output->set_header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-type, Accept");
            $this->output->set_header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
            $this->output->set_header("Access-Control-Allow-Origin: *");

            if($token != NULL) {
                $this->output->set_header("Access-Control-Expose-Headers: Authorization");
                $this->output->set_header("Authorization: " . $token);
            }
        }

        protected function _parse_post() {
            if($this->request->format === 'json') {
                //Truc per tal que el JSON quedi ben carregat (parsejat) a $_POST
                $_POST = json_decode(file_get_contents('php://input'), true);
            }
            parent::_parse_post();
        }

        protected function setOptions() {
            $this->output->set_header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-type, Accept, Authorization");
            $this->output->set_header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
            $this->output->set_header("Access-Control-Allow-Origin: *");
            //$this->output->set_header("Authentication: Beared xxx");

            $this->response(NULL, REST_Controller::HTTP_OK);
        }

        protected function createSessionJWToken($uname) {
            return $this->token->createToken($uname);
        }

        protected function getRequestJWToken() {
            $data = array();

            if($this->head('Authorization') == NULL) {
                $data['error'] = TRUE;
                $data['msg'] = 'Token not send';
            } else {
                $tokenHeader = explode(' ', $this->head('Authorization'));
                if(count($tokenHeader) != 2) {
                    $data['error'] = TRUE;
                    $data['msg'] = 'Incorrect token format';
                }
                try{
                    $token_str = JWT::decode($tokenHeader[1],$this->config->item('jwt_key'),array('HS256'));
                    $data['error'] = FALSE;
                    $data['token'] = $token_str;
                } catch(Exception $e) {
                    $data['error'] = TRUE;
                    $data['msg'] = print_r($e->getMessage(), TRUE);
                }
            }
            return $data;
        }

        protected function encodeJWToken($token) {
            return JWT::encode($token, $this->config->item('jwt_key'));
        }

        protected function prepareResponseHeaders($uname) {
            //Check is renewal is nedded
            if($this->token->expiredToken($uname)) {
                //echo "true";
                $token = $this->token->createToken($uname);
                $this->setHeaders($this->encodeJWToken($token));
            } else {
                //echo "false";
                $this->setHeaders();
            }
        }
    }
?>