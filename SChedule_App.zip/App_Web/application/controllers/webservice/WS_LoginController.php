<?php
    use Restserver\Libraries\REST_Controller;
    require_once(APPPATH . 'controllers/webservice/WS_Controller.php');

    class WS_LoginController extends WS_Controller {

        public function __construct() {
            parent::__construct();

            $this->load->helper('form');
            $this->load->library('form_validation');

            $this->load->model('admin');
        }

        public function login_post() {
            $this->form_validation->set_rules('dni', "dni", 'required');
            $this->form_validation->set_rules('passwd', 'Contrassenya', 'required');

            if($this->form_validation->run() == FALSE) {
                $rdata = array(
                    'message' => validation_errors()
                );
                $this->preparePublicDataResponse($rdata, REST_Controller::HTTP_BAD_REQUEST);
            } else {
                //Comprovar les dades i fer login
                if($this->admin->userExists($this->input->post('dni'))) {
                    if($this->admin->checkUserPasswd($this->input->post('dni'), $this->input->post('passwd'))) {
                        $rdata = array(
                            'dni' => $this->input->post('dni')
                        );
                        $this->preparePublicDataResponse($rdata, REST_Controller::HTTP_OK);
                    }
                }
                //Error
                $rdata = array(
                    'message' => "Credencials d'usuari incorrectes"
                );
                $this->preparePublicDataResponse($rdata, REST_Controller::HTTP_BAD_REQUEST);
            }
        }

        public function login_options() {
            $this->setOptions();
        }

        private function preparePublicDataResponse($rdata, $status = REST_Controller::HTTP_OK) {
            if($status == REST_Controller::HTTP_OK) {
                $tdata = $this->createSessionJWToken($rdata['dni']);
                $this->setHeaders($this->encodeJWToken($tdata));
            } else {
                $this->setHeaders();
            }
            $this->response($rdata, $status);
        }
    }
?>