<?php
    use Restserver\Libraries\REST_Controller;
    require_once(APPPATH . 'controllers/webservice/WS_Controller.php');

    class WS_ScheduleController extends WS_Controller {

        public function __construct() {
            parent::__construct();

            $this->load->model('workers');
            $this->load->model('admin');

            $this->load->helper('form');

            $this->load->library('form_validation');
        }

        public function getWorkers_get() {
            $tdata = $this->getRequestJWToken();

            if($tdata['error'] === FALSE) {
                $workers = $this->workers->getworkers();
                $this->preparePublicDataResponse($tdata['token']->uname, $workers);
            } else {
                $this->preparePublicDataResponse(NULL, $tdata['msg'], REST_Controller::HTTP_BAD_REQUEST);
            }
        }

        public function getWorkers_post() {}
        public function getWorkers_put() {}
        public function getWorkers_delete() {}

        public function getWorkers_options() {
            $this->setOptions();
        }

        public function getWorkers_head() {}
        public function getWorkers_patch() {}
        
        public function getWorkersDetail_post() {
            $tdata = $this->getRequestJWToken();

            if($tdata['error'] === FALSE) {
                //Ens hem d'imaginar que, sigui mòbil o sigui web, hi ha un formular post al darrera
                $this->form_validation->set_rules('dni', 'Worker DNI', 'required');
                if($this->form_validation->run() == FALSE) {
                    $rdata = array(
                        'message' => validation_errors()
                    );
                    $this->preparePublicDataResponse(NULL, $rdata, REST_Controller::HTTP_BAD_REQUEST);
                } else {
                    $detail = $this->workers->getWorkersByDni($this->input->post('dni'));
                    $user = $this->admin->getPublicUserData($detail->uname);

                    $rdata = array(
                        'dni' => $detail->dni,
                        'uname' => $detail->uname,
                        'rname' => $detail->rname,
                        'email' => $detail->email
                    );
                    $this->preparePublicDataResponse($tdata['token']->uname, $rdata);
                }
            } else {
                $this->preparePublicDataResponse(NULL, $tdata['msg'], REST_Controller::HTTP_BAD_REQUEST);
            }
        }

        public function getWorkersDetail_options() {
            $this->setOptions();
        }

        public function canEditWorkers_post() {
            $tdata = $this->getRequestJWToken();

            if($tdata['error'] === FALSE) {
                //Ens hem d'imaginar que, sigui mòbil o sigui web, hi ha un formular post al darrera
                $this->form_validation->set_rules('dni', 'dni', 'required');
                if($this->form_validation->run() == FALSE) {
                    $rdata = array(
                        'message' => validation_errors()
                    );
                    $this->preparePublicDataResponse(NULL, $rdata, REST_Controller::HTTP_BAD_REQUEST);
                } else {
                    $detail = $this->workers->getWorkersByDni($this->input->post('dni'));
                    if($detail->dni == $tdata['token']->dni) {
                        $rdata = array('retValue' => TRUE);
                    } else {
                        $rdata = array('retValue' => FALSE);
                    }
                    $this->preparePublicDataResponse($tdata['token']->dni, $rdata);
                }
            } else {
                $this->preparePublicDataResponse(NULL, $tdata['msg'], REST_Controller::HTTP_BAD_REQUEST);
            }
        }

        public function canEditWorkers_options() {
            $this->setOptions();
        }

        public function editWorkers_post() {
            $tdata = $this->getRequestJWToken();

            if($tdata['error'] === FALSE) {
                //Ens hem d'imaginar que, sigui mòbil o sigui web, hi ha un formular post al darrera
                $this->form_validation->set_rules('dni', 'dni', 'required');
                $this->form_validation->set_rules('uname', 'nom usuari', 'required');
                $this->form_validation->set_rules('rname', 'nom complet', 'required');
                if($this->form_validation->run() == FALSE) {
                    $rdata = array(
                        'message' => validation_errors()
                    );
                    $this->preparePublicDataResponse(NULL, $rdata, REST_Controller::HTTP_BAD_REQUEST);
                } else {
                    $detail = $this->workers->getWorkersByDni($this->input->post('dni'));
                    if($detail->uname == $tdata['token']->uname) {
                        $this->news->editNews($this->input->post('dni'), $this->input->post('uname'), $this->input->post('rname'));
                        $rdata = array('message' => 'Updated');
                    } else {
                        $rdata = array('message' => 'Forbidden');
                    }
                    $this->preparePublicDataResponse($tdata['token']->uname, $rdata);
                }
            } else {
                $this->preparePublicDataResponse(NULL, $tdata['msg'], REST_Controller::HTTP_BAD_REQUEST);
            }
        }

        public function editWorkers_options() {
            $this->setOptions();
        }

        private function preparePublicDataResponse($uname, $rdata, $status = REST_Controller::HTTP_OK) {
            //Pensar com jugar amb l'$uname
            if($uname == NULL) {
                $this->setHeaders();
            } else {
                $this->prepareResponseHeaders($uname);
            }
            $this->response($rdata, $status);
        }
    }
?>