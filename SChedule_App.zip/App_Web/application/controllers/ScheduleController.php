<?php
    class ScheduleController extends CI_Controller {

        const NEWS_PER_PAGE = 5;
        private $npage = 0;
        private $year;
        private $month;

        public function __construct() {
            parent::__construct();

            // $this->load->model('schedule');
            $this->load->model('admin');
            $this->load->model('workers');

            $this->load->helper('url_helper');
            $this->load->helper('date');

            $this->load->library('calendar');
            $this->load->library('email');

            //Configure year & month
            //$this->month = mdate("%m");
            //$this->year = mdate("%Y");

            //Configure pagination
            $this->load->library('pagination');
            $pag['per_page'] = self::NEWS_PER_PAGE;
            $pag['num_links'] = 2;
            $pag['first_link'] = 'Primeres';
            $pag['last_link'] = 'Últimes';
            $pag['num_tag_open'] = "<span style='margin: 5px;'>";
            $pag['num_tag_close'] = "</span>";
            $this->pagination->initialize($pag);

            //Check session
            $this->load->helper('cookie');
            if(get_cookie('ci_session') != NULL) {
                $this->load->library('session');
            }
        }

        public function index() {
            $this->page();
        }

        public function view($id) {
            $data['schedule'] = $this->schedule->getNewsById($id);
            $user = $this->user->getPublicUserData($data['schedule']->uname);
            $data['author'] = $user->firstname . " " . $user->surname1 . " " . $user->surname2;
            $data['title'] = 'Detalls de la notícia';
            if(isset($this->session)) {
                $data['rname'] = $this->session->rname;
                $data['uname'] = $this->session->uname;
            }

            $this->load->view('templates/header', $data);
            $this->load->view('pages/schedule', $data);
            $this->load->view('templates/footer');
        }

        public function bydate($year, $month, $day, $num=NULL) {
            if($num === NULL) {
                $num = 0;
            }
            
            $data['calendar'] = $this->configureCalendar($month, $year);
            
            $data['news'] = $this->news->getNewsByDay($day, $month, $year, $num, self::NEWS_PER_PAGE);
            $data['title'] = 'Notícies del dia ' . $day . '/' . $month . '/' . $year;
            if(isset($this->session)) {
                $data['rname'] = $this->session->rname;
                $data['uname'] = $this->session->uname;
            }

            //Pagination
            $pag['base_url'] = site_url('news/'.$year.'-'.$month.'-'.$day);
            $pag['total_rows'] = $this->news->getTotalNumOfNewsInDay($day, $month, $year);
            $pag['uri_segment'] = 3;
            $this->pagination->initialize($pag);
            $data['pagination'] = $this->pagination->create_links();            

            $this->load->view('templates/header', $data);
            $this->load->view('pages/news/index', $data);
            $this->load->view('templates/footer');
        }

        public function page($num=NULL) {
            if($num === NULL) {
                $num = 0;
            }

            //$data['calendar'] = $this->configureCalendar(mdate('%m'), mdate('%Y'), TRUE);

            //$data['schedule'] = $this->schedule->getNews($num, self::NEWS_PER_PAGE);
            $data['title'] = 'Últimes notícies';
            if(isset($this->session)) {
                $data['rname'] = $this->session->rname;
                $data['uname'] = $this->session->uname;
            }

            //Pagination
            $pag['base_url'] = site_url('news/page');
            //$pag['total_rows'] = $this->news->getTotalNumOfNews();
            $pag['uri_segment'] = 3;
            $this->pagination->initialize($pag);
            $data['pagination'] = $this->pagination->create_links();            

            $this->load->view('templates/header', $data);
            $this->load->view('pages/schedule', $data);
            $this->load->view('templates/footer');
        }

        public function create() {
            if(!isset($this->session)) {
                redirect('schedule');
            }
            if(isset($this->session)) {
                $data['rname'] = $this->session->rname;
                $data['uname'] = $this->session->uname;
            }


            $this->load->helper('form');
            $this->load->library('form_validation');

            $this->form_validation->set_rules('dni', 'DNI', 'required');
            $this->form_validation->set_rules('nom', 'NOM', 'required');
            $this->form_validation->set_rules('cognoms', 'COGNOMS', 'required');
            $this->form_validation->set_rules('passwd', 'PASSWORD', 'required');
            $this->form_validation->set_rules('birth', 'BIRTH', 'required');
            $this->form_validation->set_rules('email', 'EMAIL', 'required');
            $this->form_validation->set_rules('idA', 'IDA', 'required');
            $this->form_validation->set_rules('idH', 'IDH', 'required');

            $data['title'] = "Nuevo Trabajador";
            $data['workers'] = $this->workers->getEmployees();

            if($this->form_validation->run() == FALSE) {
                $this->load->view('templates/header', $data);
                $this->load->view('pages/user/create');
                $this->load->view('templates/footer');
            } else {
                $this->news->setUser($this->input->post('dni'), $this->input->post('nom'), $this->input->post('cognoms'), $this->input->post('passwd'), $this->session->uname);

                //Check for confirmation email
                if($this->input->post('confirm') != NULL) {
                    $econfig = array(
                        'protocol' => 'smtp',
                        'smtp_host' => 'ssl://smtp.gmail.com',
                        //'smtp_user' => 'daw2.iescaparrella@gmail.com',
                        'smtp_user' => 'macervero.examuf2@gmail.com',
                        'smtp_pass' => 'macervero',
                        'smtp_port' => 465,
                        'mailtype' => 'html',
                        'charset' => 'utf-8',
                        'newline' => "\r\n",
                        'crlf' => "\r\n"
                    );
                    $this->email->initialize($econfig);
                
                    $this->email->from('daw2.iescaparrella@gmail.com','Aplicació de notícies - DAW2');
                    $this->email->to($this->session->eaddr);
                    $this->email->subject($this->input->post('title'));   
                    $this->email->message($this->input->post('content'));
                
                    $result = $this->email->send();

                    if(!$result) {
                        show_error($this->email->print_debugger());
                    }
                }

                //Redirect, from url_helper
                redirect('news');
            }
        }
    }
?>