<?php

class AdminController extends CI_Controller{
    public function __construct(){
        parent::__construct();
        
        //$this->load->library('session');
        $this->load->helper('url_helper');
        $this->load->model('admin');
        $this->load->helper('form');
        $this->load->library('form_validation');
    }

    public function profile() {
        //Check session
        $this->load->helper('cookie');

        if(get_cookie('ci_session') != NULL) {
            $this->load->helper('form');
            $this->load->library('session');
        }else{
            redirect ('login');
        }

        $data = $this->admin->getPublicUserData($this->session->uname);

        $this->load->view('templates/header');
        $this->load->view('admin/profile', $data);
        $this->load->view('templates/footer');
    }

    public function messages(){
        //Check session
        $this->load->helper('cookie');

        if(get_cookie('ci_session') != NULL) {
            $this->load->helper('form');
            $this->load->library('session');
        }else{
            redirect ('login');
        }

        $this->load->view('templates/header');
        $this->load->view('admin/messages');
        $this->load->view('templates/footer');
    }
}

?>