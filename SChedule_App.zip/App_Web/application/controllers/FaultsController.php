<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class FaultsController extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model("Faults");
		$this->load->helper("url_helper");
		$this->load->helper("cookie");
		$this->load->helper("form");

		//Check session
            $this->load->helper('cookie');
            if(get_cookie('ci_session') != NULL) {
                $this->load->library('session');
            }
	}

	public function index()
	{
		$Workers = $this->Faults->getFaults();
		$this->layout->view("Employees", compact("Employees"));
    }

    public function faults() {
            if(!isset($this->session)) {
                redirect('schedule');
            }
            if(isset($this->session)) {
                $data['rname'] = $this->session->rname;
                $data['uname'] = $this->session->uname;
            }


            $this->load->helper('form');
            $this->load->library('form_validation');

            $this->form_validation->set_rules('dniT', 'DNIT', 'required');
            $this->form_validation->set_rules('nomT', 'NOMT', 'required');
            $this->form_validation->set_rules('cognomsT', 'COGNOMST', 'required');
            $this->form_validation->set_rules('idA', 'IDA', 'required');
            $this->form_validation->set_rules('motiu', 'MOTIU', 'required');

            $data['title_fault'] = "Nueva Falta";
            $data['Faults'] = $this->Faults->getFaults();

            if($this->form_validation->run() == FALSE) {
                $this->load->view('templates/header', $data);
                $this->load->view('pages/user/faults');
                $this->load->view('templates/footer');
            } else {
				$dniT = $_POST["dniT"];
			$nomT = $_POST["nomT"];
			$cognomsT = $_POST["cognomsT"];
			$idA = $_POST["idA"];
			$motiu = $_POST["motiu"];
			if ($this->Faults->setFault($dniT, 
											$nomT, 
											$cognomsT,
											$idA,
                                            $motiu))
			{
				
				$data["correct"] = TRUE;
				$data['Faults'] = $this->Faults->getFaults();
				
				$this->load->view('templates/header');
                $this->load->view('pages/user/faults', $data);
                $this->load->view('templates/footer');
			}
		}
    }
    
    public function saveFault()
	{
		if($this->input->post())
		{
			$dniT = $_POST["dniT"];
			$nomT = $_POST["nomT"];
			$cognomsT = $_POST["cognomsT"];
			$idA = $_POST["idA"];
			$motiu = $_POST["motiu"];
			if ($this->Faults->setFault($dniT, 
											$nomT, 
											$cognomsT,
											$idA,
                                            $motiu))
			{
				$data["correct"] = TRUE;
				$this->load->view('templates/header');
                $this->load->view('pages/user/faults', $data);
                $this->load->view('templates/footer');
			}

		}
	}
}

?>  