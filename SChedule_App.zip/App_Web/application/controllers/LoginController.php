<?php

class LoginController extends CI_Controller{

    public function __construct(){
        parent::__construct();

        //$this->load->library('session');
        $this->load->helper('url_helper');
        $this->load->model('admin');
        $this->load->helper('form');
        $this->load->library('form_validation');
    }

    public function register() {
        //Check session
        $this->load->helper('cookie');
        if(get_cookie('ci_session') != NULL) {
            redirect('schedule');
        }

        $this->form_validation->set_rules('rname', 'nombre y apellidos', 'required');
        $this->form_validation->set_rules('eaddr', 'correo electronico', 'required');
        $this->form_validation->set_rules('uname', "nombre de usuario", 'required');
        $this->form_validation->set_rules('passwd', 'contraseña', 'required');

        if($this->form_validation->run() == FALSE) {
            $data['title'] = "Registre / Inici de sessió";
            $this->loadView('login', $data);
        }
        else {
            //Guardar les dades i fer login
            if(!$this->admin->userExists($this->input->post('uname'))) {
                $this->admin->addUser($this->input->post('rname'), 
                                        $this->input->post('uname'),$this->input->post('email'),
                                        $this->input->post('passwd'));
                $this->manageSessionData($this->input->post('uname'));
            //redirect('schedule');
            }
            //Redirect to error page
            $data['title'] = "Registre / Inici de sessió";
            $data['error_msg'] = "L'usuari ja existeix al sistema";
            $this->loadView('error', $data);
        }
    }

    public function login() {
        //Check session
        $this->load->helper('cookie');
        if(get_cookie('ci_session') != NULL) {
            redirect('schedule');
        }

        $this->load->helper('form');
        $this->load->library('form_validation');

        $this->form_validation->set_rules('uname', "Nom d'usuari", 'required');
        $this->form_validation->set_rules('passwd', 'Contrassenya', 'required');

        if($this->form_validation->run() == FALSE) {
            $data['title'] = "Registre / Inici de sessió";
            $this->loadView('login', $data);
        } else {
            //Comprovar les dades i fer login
            if($this->admin->userExists($this->input->post('uname'))) {
                if($this->admin->checkUserPasswd($this->input->post('uname'), $this->input->post('passwd'))) {
                    $this->manageSessionData($this->input->post('uname'));
                }
            }
            //Redirect to error page
            $data['title'] = "Registre / Inici de sessió";
            $data['error_msg'] = "Credencials d'usuari incorrectes";
            $this->loadView('error', $data);
        }
    }

    public function logout() {
        //Check session
        $this->load->helper('cookie');
        if(get_cookie('ci_session') != NULL) {
            $this->load->helper('form');
            $this->load->library('session');

            if($this->input->post('logout') == NULL && $this->input->post('continue') == NULL) {
                $data['title'] = "Tancar sessió";
                $data['rname'] = $this->session->rname;
                $this->loadView('logout', $data);
                return;
            } else if($this->input->post('logout') != NULL) {                   
                unset($_SESSION);
                error_log(var_dump($_SESSION));
                $this->session->sess_destroy();
                delete_cookie('ci_session');
            }
        }
        redirect('login');
    }

    private function loadView($page, $data) {
        $this->load->view('templates/header', $data);
        $this->load->view('pages/login/' . $page);
        $this->load->view('templates/footer');
    }

    private function manageSessionData($uname) {
        //Start & manage SESSION
        $this->load->library('session');
        $udata = $this->admin->getPublicUserData($uname);

        $this->session->uname = $udata->uname;
        //$this->session->rname = $udata->firstname . " " . $udata->surname1 . " " . $udata->surname2;
        $this->session->eaddr = $udata->email;

        //Redirect, from url_helper
        redirect('login');
    }


    public function index(){
        $this->load->view('templates/header');
        $this->load->view('pages/login/login');
    }
}
?>