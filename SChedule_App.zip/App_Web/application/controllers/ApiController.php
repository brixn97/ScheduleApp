<?php

class ApiController extends CI_Controller{
    public function __construct(){
        header('Access-Control-Allow-Origin: *');
        header('Content-Type: application/json');
        header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
        parent::__construct();

        $this->load->model('workers');
        $this->load->model("Incidencias");
        $this->load->model('Mensajes');
    }

    public function checkUser(){
        $params = (array) json_decode(file_get_contents('php://input'), TRUE);
        $uname = $params['uname'];
        $pass = $params['pass'];

        if($this->workers->userExists($uname)) {
            if($this->workers->checkUserPasswd($uname, $pass)) {
                //$id = $this->workers->getEmployeeId($uname);
                
                echo json_encode(['success' => sha1($uname.$pass)]);
            }else{
                echo json_encode($result['error'] =  ['error' => 'Error1']);
            }
        }else{
            echo json_encode(['error' => 'Error2']);
        }
               
    }

    public function saveIncidencia() {
        $params = (array) json_decode(file_get_contents('php://input'), TRUE);
        
        $descripcio = $params['descripcion'];
        $idT = $params['idT'];
        $idA = $params['idA'];
        $motiu = $params["titulo"];
        if ($this->Incidencias->setIncidencia($motiu, $descripcio, $idA, 1))
        {
            echo json_encode(['success' => 'Correct']);
           
        }else{
            echo json_encode(['error' => 'Error2']);
        }
    }
    
    public function saveMessage() {
        $params = (array) json_decode(file_get_contents('php://input'), TRUE);
        
        $descripcio = $params['descripcion'];
        $idT = $params['idT'];
        $idA = $params['idA'];
        $motiu = $params["titulo"];
        if ($this->Mensajes->setMessage($motiu, $descripcio, $idA, 1))
        {
            echo json_encode(['success' => 'Correct']);
           
        }else{
            echo json_encode(['error' => 'Error2']);
        }
	}
}