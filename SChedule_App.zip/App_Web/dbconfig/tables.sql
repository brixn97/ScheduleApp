DROP TABLE IF EXISTS Falta ;
DROP TABLE IF EXISTS Incidencia ;
DROP TABLE IF EXISTS Estructura ;
DROP TABLE IF EXISTS Activitats ;
DROP TABLE IF EXISTS Hores ;
DROP TABLE IF EXISTS Treballador ;
DROP TABLE IF EXISTS Horari ;
DROP TABLE IF EXISTS Administrador ;


CREATE TABLE Administrador
(
    id serial PRIMARY KEY,
    rname varchar(20),
    email varchar(50),
    uname varchar(50),
    passwd varchar(50)
);

CREATE TABLE Horari
(
    id serial PRIMARY KEY,
    mati varchar(50),
    tarda varchar(50),
    idA int REFERENCES Administrador(id)
);

CREATE TABLE Treballador
(
    dni varchar(20) PRIMARY KEY,
    nom varchar(20),
    cognoms varchar(20),
    passwd varchar(50),
    birth date,
    email varchar(40),
    idA int REFERENCES Administrador(id),
    idH int REFERENCES Horari(id)
);

CREATE TABLE Hores
(
    id serial PRIMARY KEY,
    dia varchar(15),
    hora_inici varchar(10),
    hora_final varchar(10)
);

CREATE TABLE Activitats
(
    id serial PRIMARY KEY,
    nom varchar(10),
    descripcio varchar(10)
);

CREATE TABLE Estructura
(
    id serial PRIMARY KEY,
    idS int REFERENCES Horari(id),
    idH INT REFERENCES Hores(id),
    idAc INT REFERENCES Activitats(id)

);

CREATE TABLE Incidencia
(
    id serial PRIMARY KEY,
    motiu text,
    idA int REFERENCES Administrador(id),
    idT varchar(20) REFERENCES Treballador(dni)
);

CREATE TABLE Falta
(
    id serial PRIMARY KEY,
    dniT varchar (20) REFERENCES Treballador(dni),
    nomT varchar(20),
    cognomsT varchar(20),
    idA int REFERENCES Administrador(id),
    motiu text
);